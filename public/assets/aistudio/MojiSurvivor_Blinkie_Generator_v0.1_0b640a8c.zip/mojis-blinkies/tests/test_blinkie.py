import sys
from pathlib import Path
from xml.etree import ElementTree as ET
import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from blinkie import generate, image_palette, load_template, make_svg, palette, rgb, FPS

@pytest.mark.parametrize('name', ['classic','ticker','arcade'])
def test_template_generates_parseable_animated_svg(name, tmp_path):
    path, colors = generate(name, label='MYTHIC MOJI', username='npub-unit-test', level=24, out=tmp_path/name)
    root = ET.parse(path).getroot()
    t = load_template(name)
    assert root.get('width') == str(t['width'])
    assert root.get('height') == str(t['height'])
    assert len(root.findall('.//{http://www.w3.org/2000/svg}g')) == FPS
    assert 'prefers-reduced-motion' in path.read_text()
    assert 'animation:frame' in path.read_text()
    assert len(colors) == 4


def test_deterministic_seed_and_user_variation(tmp_path):
    a,_ = generate(out=tmp_path/'a', username='user-a')
    b,_ = generate(out=tmp_path/'b', username='user-a')
    c,_ = generate(out=tmp_path/'c', username='user-b')
    assert a.read_bytes() == b.read_bytes()
    assert a.read_bytes() != c.read_bytes()


def test_avatar_sampling_and_contrast_boost(tmp_path):
    from PIL import Image, ImageDraw
    im=Image.new('RGBA',(120,80),(0,0,0,0))
    draw=ImageDraw.Draw(im)
    draw.rectangle([0,0,39,79],fill='#260088')
    draw.rectangle([40,0,79,79],fill='#059D9E')
    draw.rectangle([80,0,119,79],fill='#D6167F')
    img=tmp_path/'pic.png';im.save(img)
    colors=image_palette(img)
    assert len(colors)==3
    assert len(set(colors))==3
    assert all(max(rgb(c))>=208 for c in colors)  # lifted for readability
    path, used=generate('ticker', avatar=str(img),out=tmp_path/'with_avatar')
    assert used[:3]==colors
    assert all(c in path.read_text() for c in colors)


def test_user_strings_do_not_break_xml(tmp_path):
    p,_=generate(label='A&B <MOJI> "XD"', username='a&"<', out=tmp_path/'escape')
    ET.parse(p)
    assert '&amp;' in p.read_text()
    assert '&lt;' in p.read_text()


def test_invalid_config(tmp_path):
    with pytest.raises(ValueError):generate(colors='#bad',out=tmp_path/'bad')
    with pytest.raises(ValueError):generate(level=-1,out=tmp_path/'badlevel')
    with pytest.raises(ValueError):generate(template_name='../not-real',out=tmp_path/'badtemplate')


def test_render_export_changes_frames(tmp_path):
    from PIL import Image, ImageChops
    p,_=generate('classic',out=tmp_path/'motion',render=True)
    assert p.with_suffix('.png').is_file()
    im=Image.open(p.with_suffix('.gif'))
    assert im.n_frames == FPS
    im.seek(0); a=im.convert('RGB').copy()
    im.seek(1); b=im.convert('RGB').copy()
    assert ImageChops.difference(a,b).getbbox() is not None
