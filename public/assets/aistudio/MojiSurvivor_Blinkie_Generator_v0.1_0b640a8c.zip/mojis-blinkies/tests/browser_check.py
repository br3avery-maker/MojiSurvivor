"""Optional Chromium smoke-test for inline SVG animation (requires Playwright + Chromium).

Run: python tests/browser_check.py
"""
from pathlib import Path
from shutil import which
from playwright.sync_api import sync_playwright
from PIL import Image, ImageChops

ROOT=Path(__file__).resolve().parents[1]
with sync_playwright() as p:
    exe=which('chromium') or which('google-chrome') or which('chromium-browser')
    browser=p.chromium.launch(headless=True, executable_path=exe, args=['--no-sandbox','--disable-dev-shm-usage'])
    page=browser.new_page(viewport={'width':660,'height':180})
    # page.set_content avoids file:// restrictions; the SVG remains untouched.
    page.set_content((ROOT/'output'/'sugar_rush.svg').read_text(),wait_until='load')
    page.wait_for_timeout(100)
    page.screenshot(path=str(ROOT/'output'/'browser_frame0.png'))
    page.wait_for_timeout(360)
    page.screenshot(path=str(ROOT/'output'/'browser_frame1.png'))
    a=Image.open(ROOT/'output'/'browser_frame0.png').convert('RGB')
    b=Image.open(ROOT/'output'/'browser_frame1.png').convert('RGB')
    diff=ImageChops.difference(a,b).getbbox()
    count=page.locator('.frame').count()
    state=page.locator('.f0').evaluate('(e)=>getComputedStyle(e).animationPlayState')
    assert diff is not None, 'animation frames did not change visually'
    assert count==8 and state=='running', f'frames={count}, state={state}'
    page.emulate_media(reduced_motion='reduce')
    name=page.locator('.f0').evaluate('(e)=>getComputedStyle(e).animationName')
    opacity=page.locator('.f0').evaluate('(e)=>getComputedStyle(e).opacity')
    assert name=='none' and opacity=='1',f'reduced-motion failure: {name} {opacity}'
    print('Chromium inline SVG: 8 frames, moving pixels, reduced motion works.')
    browser.close()
