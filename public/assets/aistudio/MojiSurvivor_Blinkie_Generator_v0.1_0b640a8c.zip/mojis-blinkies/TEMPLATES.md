# Blinkie templates — design spec v0.1

**Invariant:** a blinkie is a standalone, shareable, looping artwork, not a cropped statistics dashboard. It should still make sense with animation disabled, at smaller sizes, and when the user has no avatar.

## Theme generation

1. Input: local avatar path (optional) plus public game-facing label, level, and stable user identifier/seed.
2. Sample high-saturation, visible pixels; discard transparent and mostly neutral pixels; favor the most common separated hues.
3. Lift dark colors for readability while preserving their hue; pad gaps with deep pink `#FF1493`, cyan `#00F0FF`, soft violet `#B388FF`, and silver-white `#F4F4FA`.
4. The main label remains white against black even if the sampled colors are too similar. **No gold-metallic foil in the standard Mythic theme.**
5. Decorative sparkles are deterministic per user+label+template; rank/level text comes from caller data, not from drawing logic.

## Animation grammar

- **Dotted blink frame:** small rectangle pixels swap between bright/secondary colors on alternate frames.
- **Moji carousel:** three original vector faces rotate among `wink`, `star`, `xeye`, and `happy`, with staggered 1–3 px vertical motion.
- **Text-art dancer:** pixel-font symbols `★ - _ + * \`` bounce, swap, and cycle colors across frames.
- **Twinkle:** silver/bright-colored four-point stars appear in deterministic positions; no random flash pattern on every reload.
- **Timing:** eight frames × 200 ms = a 1.6-second seamless loop; motion stops on `prefers-reduced-motion`.

## Design matrix

| Layout | Border | Animation | Personality |
|---|---|---|---|
| `classic` | `dots` | `bounce` | **Sugar Rush:** true blinkie energy, four-pixel headline, three rotating Mojis |
| `ticker` | `checker` | `march` | **Glitter Parade:** moving punctuation, strong pixel checker frame, avatar colors |
| `arcade` | `comet` | `sparkle` | **Cursed Dial-Up:** blinking faux-terminal status, comet-like border |
| `ticker` | `dots` | `sparkle` | **Angel Glitch:** airy silver/pink shimmer, ribbon-style information |

**Composition swaps are supported.** Want `classic + checker + march` or `arcade + dots + bounce`? Copy any template JSON, change only those three fields, and generate. No artwork regeneration required.

### Suggested next experiments (not implemented in this package)

- A proper vintage **88 × 31 px** condensed blinkie using 3×5 font and short labels.
- Animated **achievement sticker collections**, one GIF per unlocked badge, arranged into an optional card front/back without flattening the data.
- Special effect families: grayscale-to-pink haunt, broken CRT, rainbow diffraction (no metallic gold), pixel hearts and cat/monster silhouette stickers.
- Avatar-accurate **MojiSurvivor sprite import**: use actual game sprite assets as rotating frames instead of the sample procedural smileys.

## Scope and boundaries

This package is a local code-rendering proof, with no Nostr login, no Nostr publication, no game data writes, no profile-picture fetch over the network, and no Android integration. It does not alter the MojiSurvivor repository. The avatar sampling path is implemented, but these previews use only a synthetic example avatar.
