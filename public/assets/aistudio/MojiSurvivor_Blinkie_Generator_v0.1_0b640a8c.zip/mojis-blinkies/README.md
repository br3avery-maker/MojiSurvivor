# MojiSurvivor blinkies — Python + animated SVG

Early-2000s webcore achievement/profile blinkies, drawn entirely from code. **No image generator, API key, hosting, or runtime network access.** This is an independent design experiment, not an installed MojiSurvivor feature.

## Quick start

Requires Python 3.10+ for SVG generation (standard library only).

```sh
python blinkie.py --out output/my_blinkie
```

Open `output/my_blinkie.svg` in Chrome, Firefox, or another modern browser to see it animate. For GIF and PNG exports, install optional dependencies:

```sh
python -m pip install -r requirements-export.txt
python blinkie.py --template classic --label 'MYTHIC MOJI' --level 24 --render --out output/my_blinkie
```

**Match a player's profile-picture colors** by passing a local PNG, JPG, or WebP. The image itself is never embedded in the SVG and is never uploaded. Saturated, distinct colors are sampled and lightened where needed against the black background.

```sh
python blinkie.py --avatar examples/sample_avatar.png --label 'PIXEL WITCH' --user 'npub1example' --template ticker --render --out output/from_avatar
```

**Manually theme a badge**, overriding the sampled colors:

```sh
python blinkie.py --colors '#FF1493,#00F0FF,#B388FF' --label 'CHAOS MOJI' --template arcade --render --out output/cursed
```

All generation is deterministic: identical `--user`, `--label`, template, chosen colors, and level → identical SVG bytes. Different user strings seed different decorative sparkle positions. The `--user` field is only a seed and an accessibility label; it is **not** burned onto the badge.

## Template system

Each template is a JSON document in `templates/` with these fields:

| Key | Accepted values | Description |
| --- | --- | --- |
| `name` | text | Human-readable name |
| `width`, `height` | integer pixels | Intrinsic vector canvas (use viewBox scaling for display) |
| `layout` | `classic`, `ticker`, `arcade` | Different content compositions |
| `border` | `dots`, `checker`, `comet` | Flashing border treatment |
| `animation` | `bounce`, `march`, `sparkle` | Dancing symbols and accents |
| `tagline` | pixel-font text | Short secondary status line |

Template JSON is not executed and is limited to known drawing primitives. Create a new variant by copying one JSON template and adjusting the fields. These values are intentionally independent: `ticker + dots + bounce`, for example, is valid. Template names are local file names, not URLs. Only local files are read.

### Data contract

The generator function is available to import from `blinkie.py`:

```python
from blinkie import generate
svg_path, chosen_colors = generate(
    template_name='classic',
    label='MYTHIC MOJI',
    username='npub1abc...',  # stable decoration seed; do not use a private key!
    level=24,
    avatar='/path/to/public-profile-pic.png',
    out='output/player-mythic',
    render=True,            # optional png + gif
)
```

The 5×7 bitmap font includes uppercase ASCII letters, numbers, and common webcore punctuation (`*+-_` etc). Other glyphs render as `?` in the visible art; full Unicode is preserved in the accessible SVG title. The avatar colors are sampled and boosted; skin tone/face fidelity is *not* the goal—only extracting a pleasing accent palette. A neutral/transparent avatar uses the default palette.

## Motion and export

- Animated SVG contains eight independent frames and embedded CSS keyframes. Loop length **1,600 ms**. No script or external resources.
- `prefers-reduced-motion: reduce` disables the motion and displays frame zero.
- Exporter renders eight static SVG snapshots via CairoSVG and assembles an actual eight-frame GIF through Pillow at **200 ms/frame**; also writes a PNG of frame zero.
- GIF/PNG are exported at **2× SVG viewBox dimensions** for crisp sharing. CSS animation isn't required for GIF playback.
- Raw SVG is a crisp, scalable web asset. GIF is portable for sites that don't support SVG animation.
- For embedding SVG in a web app, use an `<img>` element with intrinsic size and a responsive `max-width:100%`, or a CSS background. Do not insert the SVG as unsanitized markup from untrusted sources.

## Gallery

| Name | Effect | Output |
| --- | --- | --- |
| **Sugar Rush** | Dancing pink/cyan dots, three cycling faces | `output/sugar_rush.*` |
| **Glitter Parade** | Checker border, marching punctuation, streamer layout | `output/glitter_parade.*` |
| **Cursed Dial-Up** | Terminal aesthetic, dotted-comet outline, cursor | `output/cursed_dialup.*` |
| **Avatar Palette** | Same templates using extracted sample colors | `output/avatar_palette.*` |
| **Angel Glitch** | Silver-pink shimmer on a dots-and-ticker mashup | `output/angel_glitch.*` |

## Verification

```sh
python -m pytest tests -q
```

Tests cover XML parsing, template schema handling, deterministic SVG bytes, variation by user, avatar extraction, color visibility, XML escaping, invalid input, actual multi-frame GIF exports, and differing GIF frames. Production game integration, device/browser visual QA, and source repository modification are out of scope for this exploratory package.

## Boundaries

The sample is intentionally a **blinkie generator**, not a website, app, account system, or replacement game. It does not fetch profiles from Nostr yet. Pass a profile image path from the actual game/app once integrated. Animation is client-side in the SVG and all exports are local. No external dependencies for `.svg` output.

**Browser smoke-check:** with local Chromium and Playwright installed, run `python tests/browser_check.py` after generating `output/sugar_rush.svg`. It verifies the SVG changes pixels over time and respects reduced-motion settings. SVG was checked inside Chromium as inline SVG because this sandbox disallows direct navigation to local `file://` images; Android WebView remains untested.
