#!/usr/bin/env python3
"""MojiSurvivor blinkies. Python builds portable, self-animated SVG.

No web services. Pillow only for optional profile-image palette extraction and GIF export;
CairoSVG only for PNG/GIF rendering. Animated SVG itself needs no dependencies.
"""
from __future__ import annotations
import argparse
import colorsys
import hashlib
import json
import math
from pathlib import Path
import random
import re
from html import escape
from xml.etree import ElementTree as ET

ROOT = Path(__file__).resolve().parent
FPS = 8
DEFAULT_COLORS = ["#FF1493", "#00F0FF", "#B388FF", "#F4F4FA"]
FACES = ("wink", "star", "xeye", "happy")
# Hand-drawn 5x7 bitmap font. Empty columns are significant. Sprite glyphs are
# generated as <rect> pixels, so the visual does not depend on browser fonts.
FONT = {
 'A':["01110","10001","10001","11111","10001","10001","10001"],
 'B':["11110","10001","10001","11110","10001","10001","11110"],
 'C':["01111","10000","10000","10000","10000","10000","01111"],
 'D':["11110","10001","10001","10001","10001","10001","11110"],
 'E':["11111","10000","10000","11110","10000","10000","11111"],
 'F':["11111","10000","10000","11110","10000","10000","10000"],
 'G':["01111","10000","10000","10111","10001","10001","01111"],
 'H':["10001","10001","10001","11111","10001","10001","10001"],
 'I':["11111","00100","00100","00100","00100","00100","11111"],
 'J':["00111","00010","00010","00010","10010","10010","01100"],
 'K':["10001","10010","10100","11000","10100","10010","10001"],
 'L':["10000","10000","10000","10000","10000","10000","11111"],
 'M':["10001","11011","10101","10101","10001","10001","10001"],
 'N':["10001","11001","10101","10011","10001","10001","10001"],
 'O':["01110","10001","10001","10001","10001","10001","01110"],
 'P':["11110","10001","10001","11110","10000","10000","10000"],
 'Q':["01110","10001","10001","10001","10101","10010","01101"],
 'R':["11110","10001","10001","11110","10100","10010","10001"],
 'S':["01111","10000","10000","01110","00001","00001","11110"],
 'T':["11111","00100","00100","00100","00100","00100","00100"],
 'U':["10001","10001","10001","10001","10001","10001","01110"],
 'V':["10001","10001","10001","10001","10001","01010","00100"],
 'W':["10001","10001","10001","10101","10101","10101","01010"],
 'X':["10001","10001","01010","00100","01010","10001","10001"],
 'Y':["10001","10001","01010","00100","00100","00100","00100"],
 'Z':["11111","00001","00010","00100","01000","10000","11111"],
 '0':["01110","10011","10101","10101","11001","10001","01110"],
 '1':["00100","01100","00100","00100","00100","00100","01110"],
 '2':["01110","10001","00001","00010","00100","01000","11111"],
 '3':["11110","00001","00001","01110","00001","00001","11110"],
 '4':["00010","00110","01010","10010","11111","00010","00010"],
 '5':["11111","10000","10000","11110","00001","00001","11110"],
 '6':["01110","10000","10000","11110","10001","10001","01110"],
 '7':["11111","00001","00010","00100","01000","01000","01000"],
 '8':["01110","10001","10001","01110","10001","10001","01110"],
 '9':["01110","10001","10001","01111","00001","00001","01110"],
 ' ':["00000"]*7,
 '★':["00100","10101","01110","11111","01110","10101","00100"],
 '>':["10000","01000","00100","00010","00100","01000","10000"],
 '<':["00001","00010","00100","01000","00100","00010","00001"],
 '-':["00000","00000","00000","11111","00000","00000","00000"],
 '_':["00000","00000","00000","00000","00000","00000","11111"],
 '+':["00000","00100","00100","11111","00100","00100","00000"],
 '*':["00000","10101","01110","11111","01110","10101","00000"],
 '`':["01000","00100","00000","00000","00000","00000","00000"],
 '.':["00000","00000","00000","00000","00000","01100","01100"],
 ':':["00000","01100","01100","00000","01100","01100","00000"],
 '/':["00001","00001","00010","00100","01000","10000","10000"],
 '!':["00100","00100","00100","00100","00100","00000","00100"],
 '?':["01110","10001","00001","00010","00100","00000","00100"],
 '#':["01010","01010","11111","01010","11111","01010","01010"],
 '=':["00000","00000","11111","00000","11111","00000","00000"],
 '@':["01110","10001","10111","10101","10111","10000","01110"],
}

def rgb(hexcolor: str) -> tuple[int, int, int]:
    if not re.fullmatch(r"#[0-9a-fA-F]{6}", hexcolor):
        raise ValueError(f"Invalid color: {hexcolor!r}")
    return tuple(int(hexcolor[i:i+2], 16) for i in (1,3,5))

def image_palette(path: str | Path, count: int = 3) -> list[str]:
    """Extract punchy/different colors from an avatar, disregarding transparent pixels."""
    from PIL import Image
    im = Image.open(path).convert('RGBA')
    im.thumbnail((96,96))
    candidates = {}
    for r,g,b,a in (im.get_flattened_data() if hasattr(im,'get_flattened_data') else im.getdata()):
        if a < 160: continue
        h,s,v = colorsys.rgb_to_hsv(r/255,g/255,b/255)
        if s < .22 or v < .24 or v > .98 and s < .3: continue
        key=(round(h*24) % 24, round(s*4), round(v*4))
        candidates.setdefault(key, []).append((r,g,b))
    ranked = sorted(candidates.values(), key=lambda bucket: len(bucket) * (0.5 + colorsys.rgb_to_hsv(*(v/255 for v in bucket[0]))[1]), reverse=True)
    selected=[]
    for bucket in ranked:
        candidate=tuple(sum(p[j] for p in bucket)//len(bucket) for j in range(3))
        if all(math.sqrt(sum((a-b)**2 for a,b in zip(candidate,old))) >= 73 for old in selected):
            selected.append(candidate)
        if len(selected)>=count: break
    # Preserve the avatar's hue, but lift dark colors for visibility on black.
    lifted=[]
    for r,g,b in selected:
        h,s,v=colorsys.rgb_to_hsv(r/255,g/255,b/255)
        rr,gg,bb=colorsys.hsv_to_rgb(h,max(.58,s),max(.82,v))
        lifted.append('#'+''.join(f'{round(ch*255):02X}' for ch in (rr,gg,bb)))
    return lifted

def palette(avatar: str | None, explicit: list[str] | None = None) -> list[str]:
    picks = explicit or (image_palette(avatar) if avatar else [])
    if explicit:
        for c in explicit: rgb(c)
    # Fallbacks remain visible if the portrait is monochrome or transparent.
    result = list(picks)[:3]
    for c in DEFAULT_COLORS:
        if len(result)>=4: break
        if c.lower() not in [x.lower() for x in result]: result.append(c)
    return result

def rect(x,y,w,h,fill,extra=""):
    return f'<rect x="{x:.2f}" y="{y:.2f}" width="{w:.2f}" height="{h:.2f}" fill="{fill}" {extra}/>'

def bitmap(text, x, y, scale=3, fill='#fff', spacing=1, wave=0, phase=0, max_width=None):
    """Draws font pixels as SVG rectangles; optional staggered dancing letters."""
    parts=[]
    max_chars=int(max_width//(6*scale)) if max_width else 10**8
    for i,ch in enumerate(text.upper()[:max_chars]):
        pat=FONT.get(ch,FONT['?'])
        offset = (int(round(math.sin((phase/8*2*math.pi)+(i*1.17))*wave)) if wave else 0)
        xx=x+i*(5+spacing)*scale
        for row,line in enumerate(pat):
            for col,b in enumerate(line):
                if b=='1': parts.append(rect(xx+col*scale,y+row*scale+offset,scale,scale,fill))
    return ''.join(parts)

def star(x,y, size, color):
    return f'<path d="M{x} {y-size} L{x+size*.23} {y-size*.23} L{x+size} {y} L{x+size*.23} {y+size*.23} L{x} {y+size} L{x-size*.23} {y+size*.23} L{x-size} {y} L{x-size*.23} {y-size*.23} Z" fill="{color}"/>'

def face(cx,cy,r,kind,accent):
    """Original procedural Moji face drawn from basic SVG primitives."""
    s=[f'<circle cx="{cx}" cy="{cy}" r="{r+3}" fill="#060509" stroke="{accent}" stroke-width="3"/>',
       f'<circle cx="{cx}" cy="{cy}" r="{r}" fill="#faf7ff"/>',
       f'<circle cx="{cx-r*.27}" cy="{cy-r*.22}" r="{r*.11}" fill="#101016"/>']
    if kind=='wink':
        s += [f'<path d="M{cx+r*.12} {cy-r*.2} l{r*.32} 0" stroke="#101016" stroke-width="3" stroke-linecap="round"/>',
              f'<path d="M{cx-r*.35} {cy+r*.18} Q{cx} {cy+r*.6} {cx+r*.34} {cy+r*.16}" fill="none" stroke="#101016" stroke-width="3" stroke-linecap="round"/>']
    elif kind=='star':
        s += [star(cx+r*.25,cy-r*.24,r*.16,accent),f'<path d="M{cx-r*.4} {cy+r*.16} Q{cx} {cy+r*.7} {cx+r*.42} {cy+r*.15} Z" fill="#111017"/>']
    elif kind=='xeye':
        s=[f'<circle cx="{cx}" cy="{cy}" r="{r+3}" fill="#060509" stroke="{accent}" stroke-width="3"/>',f'<circle cx="{cx}" cy="{cy}" r="{r}" fill="#faf7ff"/>']
        for ex in (cx-r*.3,cx+r*.3):
            s.append(f'<path d="M{ex-r*.09} {cy-r*.35} l{r*.18} {r*.18} m0 {-r*.18} l{-r*.18} {r*.18}" fill="none" stroke="#15121a" stroke-width="3"/>')
        s.append(f'<path d="M{cx-r*.32} {cy+r*.33} Q{cx} {cy+r*.03} {cx+r*.32} {cy+r*.33}" fill="none" stroke="#15121a" stroke-width="3"/>')
    else:
        s += [f'<circle cx="{cx+r*.25}" cy="{cy-r*.22}" r="{r*.11}" fill="#101016"/>', f'<path d="M{cx-r*.36} {cy+r*.13} Q{cx} {cy+r*.72} {cx+r*.36} {cy+r*.13} Z" fill="#101016"/>']
    if kind=='wink':
        s.append(f'<path d="M{cx-r*.04} {cy+r*.41} q{r*.1} {r*.23} {r*.2} 0" fill="#ff1493" stroke="#ff1493" stroke-width="3"/>')
    return ''.join(s)

def load_template(name):
    path=ROOT/'templates'/f'{name}.json'
    if not path.is_file(): raise ValueError(f'Unknown template: {name}')
    data=json.loads(path.read_text(encoding='utf-8'))
    required={'name','width','height','layout','border','animation','tagline'}
    if not required.issubset(data): raise ValueError(f'Incomplete template: {name}')
    if data['layout'] not in {'classic','ticker','arcade'}: raise ValueError('Invalid layout')
    if data['border'] not in {'dots','checker','comet'}: raise ValueError('Invalid border')
    if data['animation'] not in {'bounce','march','sparkle'}: raise ValueError('Invalid animation')
    return data

def blinking_border(w,h,border,phase,colors):
    pieces=[]
    active=colors[0] if phase%2 else '#f6f4ff'
    if border=='dots':
        for x in range(8,w-8,12):
            color=active if ((x//12+phase)%3 != 0) else colors[1]
            pieces.extend([rect(x,5,6,6,color),rect(x,h-11,6,6,color)])
        for y in range(17,h-13,12):
            color=active if (y//12+phase)%3 != 0 else colors[1]
            pieces.extend([rect(5,y,6,6,color),rect(w-11,y,6,6,color)])
    elif border=='checker':
        for x in range(5,w-5,8):
            color=colors[(x//8+phase)%3] if (x//8+phase)%2 else '#fff'
            pieces.extend([rect(x,5,8,8,color),rect(x,h-13,8,8,color)])
        for y in range(13,h-13,8):
            color=colors[(y//8+phase)%3] if (y//8+phase)%2 else '#fff'
            pieces.extend([rect(5,y,8,8,color),rect(w-13,y,8,8,color)])
    else:
        pieces=[f'<rect x="7" y="7" width="{w-14}" height="{h-14}" rx="11" fill="none" stroke="{active}" stroke-width="4" stroke-dasharray="3 7" stroke-dashoffset="{phase*3}"/>',
                f'<rect x="12" y="12" width="{w-24}" height="{h-24}" rx="8" fill="none" stroke="{colors[1]}" stroke-width="1"/>']
    return ''.join(pieces)

def accents(w,h,seed,phase,colors,n=12):
    r=random.Random(seed)
    out=[]
    for i in range(n):
        x=r.randrange(28,w-22); y=r.choice([r.randrange(18,30), r.randrange(h-30,h-18)])
        bright=(i+phase)%4==0
        if bright:out.append(star(x,y,4+(i%3),colors[(i+phase)%3]))
    return ''.join(out)

def moji_strip(x,y,r,phase,colors):
    # Cycle position + expression without relying on system emoji fonts.
    result=[]
    for i in range(3):
        kind=FACES[(phase//2+i)%len(FACES)]
        bob=([0,-3,-1,2,0,-2,1,2][(phase+i*2)%8])
        result.append(face(x+i*(r*2+9),y+bob,r,kind,colors[(i+phase//2)%3]))
    return ''.join(result)

def frame_content(template, label, username, level, colors, seed, phase):
    w=template['width']; h=template['height']; layout=template['layout']; border=template['border']; anim=template['animation']
    s=[rect(0,0,w,h,'#000000'),rect(14,14,w-28,h-28,'#100b17', 'rx="7"'),blinking_border(w,h,border,phase,colors)]
    # Primary text is guaranteed readable on a stable black background.
    main_label=label.upper()
    if layout=='classic':
        s += [bitmap(main_label,27,24,scale=4,fill='#ffffff',max_width=w-260),
              rect(26,61,w-220,4,colors[phase%3]),
              bitmap(f'LV {level}  {template["tagline"]}',30,74,scale=2,fill=colors[1],max_width=w-205),
              moji_strip(w-159,54,18,phase,colors)]
    elif layout=='ticker':
        s += [star(44,49,13,colors[phase%3]),
              bitmap(main_label,66,23,scale=4,fill=colors[0],max_width=w-245),
              bitmap(f'{template["tagline"]}   LV {level}',68,64,scale=2.5,fill='#ffffff',max_width=w-235),
              moji_strip(w-140,59,16,phase,colors),
              rect(66,51,w-230,4,colors[(phase//2)%3])]
    else:
        s += [rect(30,27,w-62,7,colors[phase%3]),
              bitmap('>> '+main_label,30,45,scale=3.4,fill='#ffffff',max_width=w-180),
              bitmap('SYSTEM ONLINE  LV '+str(level),30,87,scale=2,fill=colors[1],max_width=w-115),
              face(w-76,69,26,FACES[(phase//2)%4],colors[0]),
              rect(w-29,89,6,11,colors[phase%3])]
    # Dancing symbols intentionally animate independently of the main label.
    symbols = '★ + - _ * ` + -' if phase%2 else '+ ★ _ - ` * - +'
    s.append(bitmap(symbols,w*.41, h-21 if layout!='arcade' else 102,scale=1.45,fill=colors[(phase//2)%3],wave=3 if anim=='bounce' else 1,phase=phase,max_width=w*.35))
    if anim=='march':
        s.append(bitmap('+-_*`',28+(phase*9)%38,h-22,scale=2,fill=colors[2]))
    if anim=='sparkle':
        s.append(star(w-45,32,6+(phase%3)*2,'#ffffff'))
    s.append(accents(w,h,seed,phase,colors))
    # Hidden title to expose data to screen readers and SVG viewers.
    return ''.join(s)

def make_svg(template,label,username,level,colors,seed,phase=None):
    w,h=template['width'],template['height']
    title=escape(f'{label} - level {level} - {username} - {template["name"]}')
    header=(f'<svg xmlns="http://www.w3.org/2000/svg" width="{w}" height="{h}" viewBox="0 0 {w} {h}" '
            f'role="img" aria-label="{title}"><title>{title}</title><desc>Animated pixel-art MojiSurvivor blinkie with a flashing border, cycling Moji expressions and dancing text art.</desc>')
    if phase is not None:
        return header+frame_content(template,label,username,level,colors,seed,phase)+'</svg>'
    css=['<style>']
    for i in range(FPS):
        start=i*100/FPS; end=(i+1)*100/FPS
        css += [f'@keyframes frame{i} {{ 0%, {max(0,start-.001):.4f}% {{ opacity:0; }} {start:.4f}%, {end-.001:.4f}% {{opacity:1;}} {end:.4f}%,100% {{opacity:0;}} }}',
                f'.f{i} {{ opacity:0; animation:frame{i} 1.6s steps(1,end) infinite; }}']
    css += ['@media (prefers-reduced-motion:reduce) { .frame {animation:none !important; opacity:0} .f0{opacity:1} }','</style>']
    groups=[f'<g class="frame f{i}">{frame_content(template,label,username,level,colors,seed,i)}</g>' for i in range(FPS)]
    return header+''.join(css)+''.join(groups)+'</svg>'

def generate(template_name='classic',label='MYTHIC MOJI',username='npub1...demo',level=24,avatar=None,colors=None,out=None,render=False):
    template=load_template(template_name)
    out=Path(out or ROOT/'output'/template_name)
    out.parent.mkdir(parents=True,exist_ok=True)
    if isinstance(colors,str): colors=[c.strip() for c in colors.split(',') if c.strip()]
    cols=palette(avatar,colors)
    if not isinstance(level,int) or level<0: raise ValueError('level must be a nonnegative integer')
    seed=int(hashlib.sha256(f'{username}\0{label}\0{template_name}'.encode()).hexdigest()[:16],16)
    animated=make_svg(template,label,username,level,cols,seed)
    ET.fromstring(animated)
    (out.with_suffix('.svg')).write_text(animated,encoding='utf-8')
    if render:
        from io import BytesIO
        from PIL import Image
        import cairosvg
        frames=[]
        for phase in range(FPS):
            static=make_svg(template,label,username,level,cols,seed,phase=phase)
            ET.fromstring(static)
            png=cairosvg.svg2png(bytestring=static.encode(),output_width=template['width']*2,output_height=template['height']*2)
            frames.append(Image.open(BytesIO(png)).convert('RGBA'))
        frames[0].save(out.with_suffix('.png'))
        frames[0].save(out.with_suffix('.gif'),save_all=True,append_images=frames[1:],duration=200,loop=0,disposal=2,optimize=False)
    return out.with_suffix('.svg'),cols

def main():
    ap=argparse.ArgumentParser(description='Generate custom MojiSurvivor animated SVG blinkies')
    ap.add_argument('--template',default='classic',help='Template: classic, ticker, arcade')
    ap.add_argument('--label',default='MYTHIC MOJI',help='Title text, pixel-font A-Z / 0-9 / basic punctuation')
    ap.add_argument('--user',default='npub1...demo',help='Used as deterministic visual seed; not shown in art')
    ap.add_argument('--level',type=int,default=24)
    ap.add_argument('--avatar',help='Path to local profile image, sampled for theme colors')
    ap.add_argument('--colors',help='Override extracted colors: #FF1493,#00F0FF,#B388FF')
    ap.add_argument('--out',default=str(ROOT/'output'/'blinkie'))
    ap.add_argument('--render',action='store_true',help='Also export a preview PNG and looping 8-frame GIF; requires Pillow and CairoSVG')
    args=ap.parse_args()
    try:
        p,colors=generate(args.template,args.label,args.user,args.level,args.avatar,args.colors,args.out,args.render)
        print(f'Created {p} (palette: {", ".join(colors)})')
    except (ValueError,FileNotFoundError,ImportError) as exc:
        ap.error(str(exc))

if __name__=='__main__':main()
