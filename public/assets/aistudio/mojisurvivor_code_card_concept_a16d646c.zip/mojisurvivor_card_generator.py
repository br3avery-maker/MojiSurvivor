#!/usr/bin/env python3
"""MojiSurvivor code-generated collector-card *design reference*.

Two deterministic, standalone SVGs (front & reverse). No images, fonts,
network, or image generation are required. All visuals are vector primitives.

Run: python mojisurvivor_card_generator.py [output-directory]
The example data below is a screenshot transcription, not authenticated data.
This is a design proof, not an integration with live MojiSurvivor saves.
"""
import hashlib
import math
import random
import sys
from pathlib import Path
from xml.sax.saxutils import escape

EXAMPLE = {
    'player': 'npub1xam5j…mqhtsa',
    'rarity': 'MYTHIC',
    'form': 'RAINBOW',
    'cycle_level': 24,
    'rebirth_tier': 0,
    'xp': 56247,
    'awards_unlocked': 8,
    'awards_total': 10,
    'best_run': 696947,
    'career_score': 1244092,
    'highest_wave': 32,
    'runs': 13,
    'defeated': 10757,
    'bosses': 13,
    'mojo_balance': 4923,
    'mojo_lifetime': 8481,
    'codex_unlocks': 929,
    'upgrade_levels': 31,
    'upgrade_total': 44,
    'spell': 'Chain Storm',
    'spell_level': 10,
    'nemesis': ':newgrounds-12:',
    'nemesis_kills': 27,
    'badges': ['Apex Bully', 'Six-Figure Survivor', 'The Cursed Banker', 'Emoji Exterminator'],
    'nostr_kind': 30078,
}

PINK = '#FF1493'
WHITE = '#F7F5FF'
MUTED = '#A9ABC0'
SILVER = '#D3D9EA'
CYAN = '#36F3EB'
PURPLE = '#A179FF'
FONTS = "'Inter', 'Arial', sans-serif"
MONO = "'DejaVu Sans Mono', monospace"


def seed_from(data):
    return int(hashlib.sha256(data['player'].encode()).hexdigest()[:15], 16)


def num(v):
    return f'{v:,}'


def txt(x, y, content, size=22, fill=WHITE, weight=500,
        anchor='start', spacing=None, family=FONTS, **kw):
    attrs = dict(x=x, y=y, fill=fill, **{'font-family': family, 'font-size': size,
                                        'font-weight': weight, 'text-anchor': anchor})
    if spacing is not None:
        attrs['letter-spacing'] = spacing
    attrs.update({k.replace('_', '-'): v for k, v in kw.items()})
    return '<text ' + ' '.join(f'{k}="{escape(str(v))}"' for k, v in attrs.items()) + '>' + escape(str(content)) + '</text>'


def rect(x, y, w, h, r=0, fill='none', stroke='none', sw=1, **kw):
    attrs = {'x': x, 'y': y, 'width': w, 'height': h, 'rx': r,
             'fill': fill, 'stroke': stroke, 'stroke-width': sw, **kw}
    return '<rect ' + ' '.join(f'{k.replace("_", "-")}="{v}"' for k, v in attrs.items()) + '/>'


def circle(cx, cy, r, fill='none', stroke='none', sw=1, **kw):
    attrs = {'cx': cx, 'cy': cy, 'r': r, 'fill': fill, 'stroke': stroke,
             'stroke-width': sw, **kw}
    return '<circle ' + ' '.join(f'{k.replace("_", "-")}="{v}"' for k, v in attrs.items()) + '/>'


def line(x1,y1,x2,y2, stroke=SILVER, sw=1, **kw):
    a={'x1':x1,'y1':y1,'x2':x2,'y2':y2,'stroke':stroke,'stroke-width':sw,**kw}
    return '<line '+' '.join(f'{k.replace("_", "-")}="{v}"' for k,v in a.items())+'/>'


def poly(points, fill, stroke='none', sw=1, **kw):
    p=' '.join(f'{x:.1f},{y:.1f}' for x,y in points)
    a={'points':p,'fill':fill,'stroke':stroke,'stroke-width':sw,**kw}
    return '<polygon '+' '.join(f'{k.replace("_", "-")}="{v}"' for k,v in a.items())+'/>'


def path(d, fill='none', stroke='none', sw=1, **kw):
    a={'d':d,'fill':fill,'stroke':stroke,'stroke-width':sw,**kw}
    return '<path '+' '.join(f'{k.replace("_", "-")}="{v}"' for k,v in a.items())+'/>'


def star(x, y, r, color=SILVER, op=1):
    return path(f'M{x:.2f} {y-r:.2f} Q{x+r*.17:.2f} {y-r*.17:.2f} {x+r:.2f} {y:.2f} '
                f'Q{x+r*.17:.2f} {y+r*.17:.2f} {x:.2f} {y+r:.2f} '
                f'Q{x-r*.17:.2f} {y+r*.17:.2f} {x-r:.2f} {y:.2f} '
                f'Q{x-r*.17:.2f} {y-r*.17:.2f} {x:.2f} {y-r:.2f} Z',
                color, opacity=op)


def defs():
    return '''<defs>
    <linearGradient id="foil" x1="0%" y1="12%" x2="100%" y2="82%">
     <stop offset="0%" stop-color="#FF1493"/><stop offset="19%" stop-color="#FF67E2"/>
     <stop offset="37%" stop-color="#A179FF"/><stop offset="55%" stop-color="#36F3EB"/>
     <stop offset="73%" stop-color="#F8F6FF"/><stop offset="87%" stop-color="#A8F5CA"/>
     <stop offset="100%" stop-color="#FF1493"/>
    </linearGradient>
    <linearGradient id="prism" x1="0%" y1="0%" x2="100%" y2="100%">
     <stop offset="0%" stop-color="#30102B"/><stop offset="36%" stop-color="#3C185C"/>
     <stop offset="62%" stop-color="#133944"/><stop offset="100%" stop-color="#240B28"/>
    </linearGradient>
    <linearGradient id="orb" x1="0" y1="0" x2="1" y2="1">
     <stop offset="0" stop-color="#FFFFFF"/><stop offset="0.62" stop-color="#E7E9F2"/>
     <stop offset="1" stop-color="#A4B2CB"/>
    </linearGradient>
    <radialGradient id="glow">
     <stop offset="0%" stop-color="#DD35F9" stop-opacity="0.30"/>
     <stop offset="45%" stop-color="#8B1AA6" stop-opacity="0.16"/>
     <stop offset="100%" stop-color="#000000" stop-opacity="0"/>
    </radialGradient>
    <pattern id="grid" width="42" height="42" patternUnits="userSpaceOnUse">
      <path d="M 42 0 L 0 0 0 42" fill="none" stroke="#9F6AC5" stroke-opacity="0.09" stroke-width="0.8"/>
    </pattern>
    </defs>'''


def svg_open():
    return '<svg xmlns="http://www.w3.org/2000/svg" width="720" height="1080" viewBox="0 0 720 1080">'+defs()


def base(seed):
    out = [rect(0,0,720,1080,fill='#000000'),
           rect(11,11,698,1058,36,fill='#09080F',stroke='url(#foil)',sw=3),
           rect(22,22,676,1036,28,fill='none',stroke='#FAE9FB',sw=.7,opacity='.52'),
           rect(36,36,648,1008,24,fill='url(#grid)'),
           rect(36,36,648,1008,24,fill='none',stroke='#4C274B',sw=1),
           rect(37,37,646,1006,24,fill='url(#glow)')]
    rng = random.Random(seed)
    for i in range(74):
        x = rng.randint(45,674)
        y = rng.randint(47,1030)
        # Restrict stars mostly to rim; keep all content clear.
        if 115 < x < 605 and 110 < y < 976:
            continue
        if i % 6==0:
            out.append(star(x,y,rng.choice([3.4,4,5.8]), SILVER, .65))
        else:
            out.append(circle(x,y, rng.choice([.7,1,1.5]),fill=CYAN if i%4==0 else PINK, opacity='.55'))
    return out


def footer(out, data, side):
    out.extend([line(70,1001,650,1001,stroke='#73738D',sw=1,opacity='.6'),
                txt(70,1028,'MOJISURVIVOR  /  NOSTR '+str(data['nostr_kind']),12,MUTED,650,spacing=1.5),
                txt(650,1028, side+'  •  '+data['player'],12,SILVER,500,anchor='end')])


def hero(out, data, seed):
    rng = random.Random(seed)
    cx, cy = 360, 462
    out.extend([
        circle(cx,cy,252,fill='url(#glow)'),
        circle(cx,cy,211,stroke='#FF1493',sw=1.0,stroke_dasharray='2 16',opacity='.48'),
        circle(cx,cy,196,stroke='#BCEFFC',sw=.9,opacity='.33'),
    ])
    # Angular foil shards: all simple SVG polygons; deterministic per npub.
    palette = ['#FF1493','#CC3BFC','#8A76FF','#39E5E0','#CCE2FF','#5B92EF']
    for i in range(16):
        a=(i*2*math.pi/16)+math.radians(-9)
        b=a+math.radians(rng.uniform(11,20))
        inner=rng.uniform(167,192)
        outer=rng.uniform(205,258)
        points=[(cx+inner*math.cos(a),cy+inner*math.sin(a)),
                (cx+outer*math.cos(a+.05),cy+outer*math.sin(a+.05)),
                (cx+outer*.90*math.cos(b),cy+outer*.90*math.sin(b)),
                (cx+(inner-15)*math.cos(b-.05),cy+(inner-15)*math.sin(b-.05))]
        out.append(poly(points,palette[i%len(palette)],opacity=str(.13+.14*(i%3))))
    # Hero emblem's rings and silhouette.
    out.extend([
        circle(cx,cy,172,fill='#05050B',stroke='#605179',sw=14),
        circle(cx,cy,174,stroke='url(#foil)',sw=8),
        circle(cx,cy,161,stroke='#F6F7FF',sw=2.5,opacity='.89'),
        circle(cx,cy,152,fill='url(#orb)'),
        circle(cx-47,cy-42,13,fill='#06060B'),
        circle(cx+47,cy-42,13,fill='#06060B'),
        # X pupils, simple paths; not dependent on emoji font.
        path(f'M {cx-64} {cy-60} l 34 36 m 0 -36 l -34 36',stroke='#0A0A10',sw=9,stroke_linecap='round'),
        path(f'M {cx+30} {cy-60} l 34 36 m 0 -36 l -34 36',stroke='#0A0A10',sw=9,stroke_linecap='round'),
        path(f'M {cx-81} {cy+45} Q {cx} {cy+119} {cx+84} {cy+34}',stroke='#0B0B11',sw=13,stroke_linecap='round'),
        path(f'M {cx+26} {cy+77} q 5 44 29 37 q 18 -6 9 -47',fill=PINK,stroke='#0D0C13',sw=6),
        path(f'M {cx+47} {cy+100} q 12 2 16 -12',stroke='#FFBBE2',sw=3),
    ])
    # Electrified chain: polygon lightning with anchor rivets.
    for x,y,scale,rot in [(121,394,1,-8),(557,502,.92,8),(258,646,.72,-18)]:
        pts=[(-7,-73),(30,-73),(7,-16),(34,-16),(-29,76),(-11,10),(-39,10)]
        a=math.radians(rot)
        new=[(x+scale*(u*math.cos(a)-v*math.sin(a)), y+scale*(u*math.sin(a)+v*math.cos(a))) for u,v in pts]
        out.append(poly(new,'#F7F8FF','#25D8F3',2.4))
        out.append(circle(x,y,9,fill='#06050A',stroke=PINK,sw=3))
    for a,b in [((155,554),(228,608)),((493,355),(567,329))]:
        x1,y1=a; x2,y2=b
        out.append(line(x1,y1,x2,y2,stroke='#DDD7F0',sw=7,opacity='.66'))
        for j in range(4):
            t=(j+.5)/4
            px=x1+t*(x2-x1);py=y1+t*(y2-y1)
            out.append(circle(px,py,9,fill='#090910',stroke=SILVER,sw=4))
    for a, b, r in [(143,290,7),(576,420,6),(183,607,11),(581,615,8),(316,228,6)]:
        out.append(star(a,b,r,SILVER))


def front(data):
    out=[svg_open()]+base(seed_from(data))
    out.extend([
        txt(67,90,'MOJI  /  SURVIVOR',20,WHITE,850,spacing=2.4),
        rect(520,59,130,42,21,fill='#15121D',stroke='url(#foil)',sw=2),
        txt(585,88,data['rarity'],19,WHITE,850,anchor='middle',spacing=1.8),
        line(68,117,651,117,stroke='#666073',sw=1),
        txt(68,160,'CHAIN STORM',46,WHITE,900,spacing=-.8),
        txt(69,184,'SIGNATURE MOJI    •    '+data['form']+' FORM',13,PINK,750,spacing=2),
        txt(69,211,f'REBIRTH {data["rebirth_tier"]:02d}    /    {num(data["xp"])} LIFETIME XP',12,SILVER,700,spacing=1.1),
    ])
    hero(out,data,seed_from(data))
    out.extend([
        txt(70,740,'CYCLE LEVEL',13,MUTED,730,spacing=2.2),
        txt(68,800,str(data['cycle_level']).zfill(2),64,WHITE,900),
        txt(164,794,'LV',18,PINK,800,spacing=1),
        line(270,728,270,803,stroke='#63536C',sw=1),
        txt(303,740,'BEST RUN',13,MUTED,730,spacing=2.2),
        txt(302,795,num(data['best_run']),46,WHITE,900,spacing=-1.8),
        txt(645,795,'PTS',14,PINK,800,anchor='end'),
        line(70,822,650,822,stroke='#5D4E67',sw=1),
        txt(70,852,f'WAVE {data["highest_wave"]}',23,CYAN,800),
        txt(650,852,f'{data["bosses"]} BOSSES',23,SILVER,800,anchor='end'),
        rect(68,877,584,82,14,fill='#111019',stroke='#363041',sw=1.1),
        txt(88,908,data['player'],18,WHITE,750),
        txt(88,937,'ACHIEVEMENTS',12,MUTED,750,spacing=1.7),
    ])
    for i in range(data['awards_total']):
        x=400+i*24.6
        if i<data['awards_unlocked']:
            out.append(poly([(x,927),(x+8,934),(x,941),(x-8,934)],'url(#foil)',stroke='#FAF7FF',sw=.8))
        else:
            out.append(poly([(x,927),(x+8,934),(x,941),(x-8,934)],'#191822',stroke='#686476',sw=1))
    footer(out,data,'01 / FRONT')
    return ''.join(out)+'</svg>'


def small_stat(out,x,y,heading,value,color=WHITE):
    out.extend([txt(x,y,heading,13,MUTED,750,spacing=1.25),
                txt(x,y+40,value,31,color,800,spacing=-.7)])


def back(data):
    out=[svg_open()]+base(seed_from(data)^0x1234)
    out.extend([
        txt(68,94,'THE CAREER ARCHIVE',34,WHITE,900,spacing=-.8),
        rect(530,61,120,36,18,fill='#120D1C',stroke='url(#foil)',sw=2),
        txt(590,85,data['rarity'],16,WHITE,850,anchor='middle',spacing=2),
        txt(70,127,'PERMANENT RECORD  /  '+data['player'],13,MUTED,650,spacing=1.0),
        line(70,149,650,149,stroke='#686077',sw=1),
        txt(70,191,'ALL-TIME CAREER SCORE',14,CYAN,760,spacing=2.1),
        txt(65,270,num(data['career_score']),65,WHITE,900,spacing=-2),
        txt(73,294,'TOTAL POINTS',12,MUTED,730,spacing=1.5),
        line(70,318,650,318,stroke='#535066',sw=1),
    ])
    # Two-column comparison lines (NOT 6 dashboard cards)
    specs=[
        ('EMOJIS DEFEATED',num(data['defeated']),CYAN),
        ('HIGHEST WAVE',str(data['highest_wave']).zfill(2),WHITE),
        ('BOSSES SLAIN',num(data['bosses']),PINK),
        ('RUNS',str(data['runs']),WHITE),
        ('MOJO BALANCE',num(data['mojo_balance']),PINK),
        ('LIFETIME MOJO',num(data['mojo_lifetime']),WHITE),
        ('CODEX ENTRIES',num(data['codex_unlocks']),CYAN),
        ('UPGRADE LEVELS',f'{data["upgrade_levels"]}/{data["upgrade_total"]}',WHITE),
    ]
    for row in range(4):
        y=348+row*102
        left=specs[2*row]; right=specs[2*row+1]
        small_stat(out,75,y,left[0],left[1],left[2])
        small_stat(out,393,y,right[0],right[1],right[2])
        out.append(line(365,y-12,365,y+47,stroke='#373342',sw=1))
        if row<3:
            out.append(line(75,y+61,642,y+61,stroke='#322C3D',sw=1))
    out.extend([
        line(70,733,650,733,stroke='#60516C',sw=1),
        txt(75,769,'SIGNATURE',13,MUTED,800,spacing=1.8),
        txt(75,807,data['spell'].upper(),26,WHITE,880,spacing=.4),
        txt(650,807,'LV '+str(data['spell_level']),21,PINK,800,anchor='end'),
        txt(75,833,f'NEMESIS: {data["nemesis"]}   /   {data["nemesis_kills"]} DEFEATED',14,SILVER,650),
        line(70,858,650,858,stroke='#60516C',sw=1),
        txt(75,890,'VERIFIED ACHIEVEMENTS',15,WHITE,850,spacing=1.4),
        txt(650,890,f'{data["awards_unlocked"]} / {data["awards_total"]}',15,CYAN,850,anchor='end'),
    ])
    # Four featured award names, not code conditions; two simple rows.
    names=data['badges'][:4]
    for i,name in enumerate(names):
        row=i//2; col=i%2
        x=77+col*300; y=916+row*34
        out.append(circle(x+8,y-6,6,fill='url(#foil)'))
        out.append(txt(x+22,y,name,15,WHITE,650))
    footer(out,data,'02 / REVERSE')
    return ''.join(out)+'</svg>'


def main():
    target=Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).resolve().parent
    target.mkdir(parents=True,exist_ok=True)
    front_path=target/'mojisurvivor_card_front.svg'
    back_path=target/'mojisurvivor_card_back.svg'
    front_path.write_text(front(EXAMPLE),encoding='utf-8')
    back_path.write_text(back(EXAMPLE),encoding='utf-8')
    print(front_path)
    print(back_path)

if __name__=='__main__':
    main()
