# MojiSurvivor — code-generated collector card concept

This is a **design proof**, not an integration or replacement for the existing in-game card exporter.

## Composition
- **Front**: true trading-card composition: huge generated hero emblem, featured spell, rarity, best run, wave, bosses, cycle level, identity, achievement progress.
- **Reverse**: clean career archive with secondary metrics, signature spell, four featured award titles, and Nostr metadata.
- **Style**: black `#000000`, deep pink `#FF1493`, cool silver, cyan, violet and prismatic rainbow (no gold).
- **Rendering**: SVG-only vector primitives and gradients. No web fonts, external images, remote services, JavaScript or generative AI required to reproduce these files.

## Regenerate

```sh
python mojisurvivor_card_generator.py
```

Edit the `EXAMPLE` dictionary in the script to supply a different player profile. The star/shard layout is seeded from the profile's displayed npub string so it stays visually consistent between regenerations. To integrate into an app, supply an authenticated save record instead of the example dictionary.

## Provenance and caveats
The example data is transcribed from the screenshot provided in the chat; it has **not** been verified against Nostr or live game state. Four award names are known from the screenshot; the other four unlocked awards are **not invented**, only the 8/10 progress count is displayed. The mockup does not implement Nostr publishing, identity verification, app interactions, or a card-export pipeline.

## Verification in this session
- Python generator executed successfully.
- Both SVGs parsed as valid XML.
- Both images were regenerated and rasterized successfully with CairoSVG.
- Determinism was checked by comparing generated contents to regenerated string output.
